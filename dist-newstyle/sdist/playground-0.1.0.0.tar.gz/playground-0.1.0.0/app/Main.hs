module Main (main) where

import Exo1
import Lib

main :: IO ()
main = someFunc
